#!/usr/bin/env python
#  -*- coding: utf-8 -*-
__author__ = 'chengzhi'

from tqsdk import TqApi, TqAuth

# 创建API实例,传入自己的信易账户
api = TqApi(auth=TqAuth("lcw001", "EsBVBuBNACE75pjg25vC"))
# 获得上期所 ni2206 的行情引用，当行情有变化时 quote 中的字段会对应更新
quote = api.get_quote("SSE.510050")

print(quote)

# 输出 ni2206 的最新行情时间和最新价
#print(quote.datetime, quote.last_price)

# 关闭api,释放资源
api.close()


# 创建API实例,传入自己的信易账户
api = TqApi(auth=TqAuth("lcw001", "EsBVBuBNACE75pjg25vC"))

q1 = api.get_quote("SHFE.cu1901")
q2 = api.get_quote("SHFE.cu1902")
k1 = api.get_kline_serial("SHFE.cu1901", 60)
k2 = api.get_kline_serial("SHFE.cu1902", 60)

ls1 = api.query_options("SSE.510300", exchange_id="SSE",expired=False)
print(ls1)  # 上交所沪深300etf期权

ls2 = api.query_options("SSE.510050", exchange_id="SSE",expired=False)
print(ls2)  # 上交所沪深300etf期权

while api.wait_update():
  print("收到数据了")        # 上面4项中的任意一项有变化, 都会到这一句. 具体是哪个或哪几个变了, 用 is_changing 判断
  if api.is_changing(q1):
    print(q1)               # 如果q1变了, 就会执行这句
  if api.is_changing(q2):
    print(q2)
  if api.is_changing(k1):
    print(k1)
  if api.is_changing(k2):
    print(k2)

