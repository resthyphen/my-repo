#!/usr/bin/env python
#  -*- coding: utf-8 -*-
__author__ = 'chengzhi'

import MySQLdb
from tqsdk import TqApi, TqAuth
import datetime
import sys, pprint
from datetime import datetime, date
from contextlib import closing
from tqsdk import TqApi, TqAuth, TqSim
from tqsdk.tools import DataDownloader

api = TqApi(auth=TqAuth("lcw001", "EsBVBuBNACE75pjg25vC"))

db = MySQLdb.connect("localhost", "root", "123456", "test2", charset='utf8' )
cursor = db.cursor()

kline_data = api.get_kline_data_series(symbol = "SSE.510050", duration_seconds=60,
            start_dt=date(2018, 4, 2), end_dt=date(2022, 3, 9))

table = "510050_ETF_kline_minute"

sql = "CREATE TABLE `%s` (`ID` INT NOT NULL AUTO_INCREMENT,`Date` VARCHAR(8) NULL DEFAULT NULL," \
                      "`Time` VARCHAR(8) NULL DEFAULT NULL,`Open` DOUBLE NULL DEFAULT 0,`High` DOUBLE NULL DEFAULT 0," \
                      "`Low` DOUBLE NULL DEFAULT 0,`Close` DOUBLE NULL DEFAULT 0,`Volume` DOUBLE NULL DEFAULT 0," \
                      "`Open_oi` DOUBLE NULL DEFAULT 0,`Close_oi` DOUBLE NULL DEFAULT 0,`Symbol` VARCHAR(32) NULL " \
                      "DEFAULT NULL,`Timestamp` BIGINT(11) NULL DEFAULT 0,PRIMARY KEY (`ID`)," \
                      "UNIQUE INDEX `ID_UNIQUE` (`ID` ASC), INDEX `Date_Time_Index` (`Date` ASC, `Time` ASC))" % table

cursor.execute(sql)
db.commit()

# try:
#     # 执行sql语句
#     cursor.execute(sql)
#     # 提交到数据库执行
#     db.commit()
# except:
#     # 发生错误时回滚
#     db.rollback()

for kline in kline_data.iloc:
    print(table)
    date_time = datetime.fromtimestamp(kline.datetime / (1E+9))
    s = date_time.strftime('%Y%m%d %H%M%S')
    a = s.split()
    sql = "INSERT INTO %s (\
                                                                       Date, Time, Open, High, Low, Close, Volume, Open_oi, Close_oi, Symbol, Timestamp) \
                                                                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, '%s', %s)" % \
          (table, a[0], a[1], kline.open, kline.high, kline.low, kline.close, kline.volume,
           kline.open_oi,
           kline.close_oi, kline.symbol, kline.datetime / (1E+9))

    cursor.execute(sql)
    db.commit()

    # try:
    #     # 执行sql语句
    #     cursor.execute(sql)
    #     # 提交到数据库执行
    #     db.commit()
    # except:
    #     # 发生错误时回滚
    #     db.rollback()