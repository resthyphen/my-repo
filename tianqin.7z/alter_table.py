#!/usr/bin/env python
#  -*- coding: utf-8 -*-
__author__ = 'chengzhi'

import MySQLdb
from tqsdk import TqApi, TqAuth
import datetime
import sys, pprint
from datetime import datetime, date
from contextlib import closing
from tqsdk import TqApi, TqAuth, TqSim
from tqsdk.tools import DataDownloader

api = TqApi(auth=TqAuth("lcw001", "EsBVBuBNACE75pjg25vC"))

#db = MySQLdb.connect("localhost", "root", "123456", "test", charset='utf8' )
db = MySQLdb.connect("localhost", "root", "123456", "test2", charset='utf8' )
#db = MySQLdb.connect("rm-uf61ry9o576bspt5pbo.mysql.rds.aliyuncs.com", "admin_options", "cNssDL2ZwjaHmaQ96D50", "db_options", charset='utf8' )
cursor = db.cursor()

#months = ["01" , "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
months = ["11"];
classes = ["CALL", "PUT"]
durations = [86400, 60]     # 1 day = 86400s

for m in months:
    for c in classes:
        for t in durations:
            ls = api.query_options("SSE.510050", option_class=c, exercise_year=2021,
                                   exercise_month=int(m))  # 所有未下市上交所上证50etf期权
            df = api.query_symbol_info(ls)
            print(df.to_string())

            prices = []  # strike price
            ids = []  # instrument_id
            d = {}  # a map(key:strike_price, value:instrument_id)

            for data in df.iloc:
                if data["instrument_name"][-1] == 'A': continue  # don't get the data which name ends with character 'A'
                print(data["instrument_name"] + " ", data["strike_price"])
                prices.append(data["strike_price"])
                ids.append(data["instrument_id"])
                d[data["strike_price"]] = data["instrument_id"]

            print(d)

            for p in prices:
                s = str(p)
                s = s.replace('.', '')

                if t == 86400:
                    table = "510050_2021" + m + '_' + c + "_" + s + "_kline_" + "day"
                else:
                    table = "510050_2021" + m + '_' + c + "_" + s + "_kline_" + "minute"

                print(table)

                sql = "ALTER TABLE `%s` ADD INDEX `Timestamp_Index` (`Timestamp` ASC) VISIBLE" % table

                # cursor.execute(sql)
                # db.commit()

                try:
                    # 执行sql语句
                    cursor.execute(sql)
                    # 提交到数据库执行
                    db.commit()
                except:
                    # 发生错误时回滚
                    db.rollback()
