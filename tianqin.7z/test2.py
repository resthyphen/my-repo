#!/usr/bin/env python
#  -*- coding: utf-8 -*-
__author__ = 'chengzhi'

import MySQLdb
from tqsdk import TqApi, TqAuth
import datetime
import sys, pprint
from datetime import datetime, date
from contextlib import closing
from tqsdk import TqApi, TqAuth, TqSim
from tqsdk.tools import DataDownloader

db = MySQLdb.connect("localhost", "root", "123456", "test", charset='utf8' )
cursor = db.cursor()

api = TqApi(auth=TqAuth("lcw001", "EsBVBuBNACE75pjg25vC"))

ls = api.query_options("SSE.510050", option_class="CALL", exercise_year=2021, exercise_month=1)  # 所有未下市上交所上证50etf期权
df = api.query_symbol_info(ls)
print(df.to_string())

prices = []             #contract price
ids = []                #instrument_id
d = {}                  #a map(key:instrument_id, value:strike_price)

for data in df.iloc:
    if data["instrument_name"][-1] == 'A': continue             #don't get the data which name ends with character 'A'
    print(data["instrument_name"] + " ", data["strike_price"])
    prices.append(data["strike_price"])
    ids.append(data["instrument_id"])
    d[data["instrument_id"]] = data["strike_price"]

prices.sort()
print(prices)
ids.sort()
print(ids)

# for key in d:
#     kline_data = api.get_kline_data_series(symbol=key, duration_seconds=60,
#                  start_dt=date(2018, 4, 2), end_dt=date(2022, 2, 13))
#     for kline in kline_data.iloc:
#         date_time = datetime.fromtimestamp(kline.datetime / (1E+9))
#         print(date_time, '\t', kline.open, '\t', kline.high, '\t', kline.low, kline.close, '\t', kline.volume, '\t', kline.open_oi, '\t', kline.close_oi)

table = '510050_202101_c_37_kline_minute'
sql = "CREATE TABLE `%s` (`ID` INT NOT NULL AUTO_INCREMENT,`Date` VARCHAR(8) NULL DEFAULT NULL," \
      "`Time` VARCHAR(8) NULL DEFAULT NULL,`Open` DOUBLE NULL DEFAULT 0,`High` DOUBLE NULL DEFAULT 0," \
      "`Low` DOUBLE NULL DEFAULT 0,`Close` DOUBLE NULL DEFAULT 0,`Volume` DOUBLE NULL DEFAULT 0," \
      "`Open_oi` DOUBLE NULL DEFAULT 0,`Close_oi` DOUBLE NULL DEFAULT 0,`Symbol` VARCHAR(32) NULL " \
      "DEFAULT NULL,`Timestamp` BIGINT(11) NULL DEFAULT 0,PRIMARY KEY (`ID`)," \
      "UNIQUE INDEX `ID_UNIQUE` (`ID` ASC) VISIBLE, INDEX `Date_Time_Index` (`Date` ASC, `Time` ASC) INVISIBLE)" % table

try:
    # 执行sql语句
    cursor.execute(sql)
    # 提交到数据库执行
    db.commit()
except:
    # 发生错误时回滚
    db.rollback()


kline_data = api.get_kline_data_series(symbol = "SSE.10002973", duration_seconds=60,
            start_dt=date(2018, 4, 2), end_dt=date(2022, 2, 13))

sym = "SSE.10002973"

for kline in kline_data.iloc:
    #print(table)
    date_time = datetime.fromtimestamp(kline.datetime / (1E+9))
    s = date_time.strftime('%Y%m%d %H%M%S')
    a = s.split()
    print(kline)
    # print(date_time, '\t', kline.open, '\t', kline.high, '\t', kline.low, kline.close, '\t', kline.volume, '\t',
    #       kline.open_oi, '\t', kline.close_oi)
    sql= "INSERT INTO %s (\
                                   Date, Time, Open, High, Low, Close, Volume, Open_oi, Close_oi, Symbol, Timestamp) \
                                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, '%s', %s)" % \
          (table, a[0], a[1], kline.open, kline.high, kline.low, kline.close, kline.volume, kline.open_oi, kline.close_oi, kline.symbol, kline.datetime / (1E+9))

    try:
        # 执行sql语句
        cursor.execute(sql)
        # 提交到数据库执行
        db.commit()
    except:
        # 发生错误时回滚
        db.rollback()

#
# for kline in kline_data.iloc:
#     print(kline)
#
# print(len(kline_data))