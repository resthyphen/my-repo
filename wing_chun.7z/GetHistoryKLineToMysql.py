import MySQLdb
import time
from tcoreapi_mq import *
import tcoreapi_mq
import threading

g_QuoteZMQKeepAlive = None
g_QuoteZMQ = None
g_QuoteSession = ""
ReportID = ""
t = None

# 打开数据库连接
db = MySQLdb.connect("192.168.0.135", "admin", "Abcd@1234", "historykline", charset='utf8')
#db = MySQLdb.connect("localhost", "root", "123456", "test", charset='utf8' )

# 使用cursor()方法获取操作游标
cursor = db.cursor()


# 实时行情回调
def OnRealTimeQuote(symbol):
    print("实时行情", symbol["HighPrice"])


# 实时Greeks回调
def OnGreeks(greek):
    print("实时Greeks", greek)


# 已登入资金账户变更
def OnGetAccount(account):
    print(account["BrokerID"])


# 实时委托回报消息
def OnexeReport(report):
    global ReportID
    print("OnexeReport:", report["ReportID"])
    ReportID = report["ReportID"]
    return None


# 实时成交回报回调
def RtnFillReport(report):
    print("RtnFillReport:", report["ReportID"])


# 行情消息接收
def quote_sub_th(obj, sub_port, filter=""):
    socket_sub = obj.context.socket(zmq.SUB)
    # socket_sub.RCVTIMEO=7000   #ZMQ超时时间设定
    socket_sub.connect("tcp://127.0.0.1:%s" % sub_port)
    socket_sub.setsockopt_string(zmq.SUBSCRIBE, filter)
    while (True):
        message = (socket_sub.recv()[:-1]).decode("utf-8")
        index = re.search(":", message).span()[1]  # filter
        message = message[index:]
        message = json.loads(message)
        # for message in messages:
        if (message["DataType"] == "REALTIME"):
            OnRealTimeQuote(message["Quote"])
        elif (message["DataType"] == "GREEKS"):
            OnGreeks(message["Quote"])
        elif (message["DataType"] == "PING"):
            obj.QuotePong(g_QuoteSession)
        elif (message["DataType"] == "TICKS" or message["DataType"] == "1K" or message["DataType"] == "DK"):
            # print("@@@@@@@@@@@@@@@@@@@@@@@",message)
            strQryIndex = ""
            while (True):
                History_obj = {
                    "Symbol": message["Symbol"],
                    "SubDataType": message["DataType"],
                    "StartTime": message["StartTime"],
                    "EndTime": message["EndTime"],
                    "QryIndex": strQryIndex
                }
                s_history = obj.get_history(g_QuoteSession, History_obj)
                historyData = s_history["HisData"]
                if len(historyData) == 0:
                    break

                table = re.sub(r'TC\.O\.SSE\.', '', History_obj["Symbol"])
                table = table.split('.', 3)
                table[3] = table[3].replace('.', '')
                sep = '_'
                table = sep.join(table)

                if History_obj["SubDataType"] == "DK":
                    table = table + '_kline_day'
                else:
                    table = table + '_kline_minute'

                print(table)

                sql = "CREATE TABLE `%s` (`ID` BIGINT(11) NOT NULL AUTO_INCREMENT,`Date` VARCHAR(8) NULL," \
                      "`Time` VARCHAR(5) NULL,`Open` DOUBLE NULL DEFAULT 0,`High` DOUBLE NULL DEFAULT 0,`Low` DOUBLE NULL DEFAULT 0," \
                      "`Close` DOUBLE NULL DEFAULT 0,`Volume` BIGINT(11) NULL DEFAULT 0,`UpTick` BIGINT(11) NULL DEFAULT 0,`UpVolume` " \
                      "BIGINT(11) NULL DEFAULT 0,`DownTick` BIGINT(11) NULL DEFAULT 0,`DownVolume` BIGINT(11) NULL DEFAULT 0," \
                      "`UnchVolume` BIGINT(11) NULL DEFAULT 0, `QryIndex` BIGINT(11) NULL DEFAULT 0, `Timestamp` BIGINT(11) NULL DEFAULT 0," \
                      "PRIMARY KEY (`ID`), UNIQUE KEY `id_UNIQUE` (`ID`), INDEX `Date_Time_Index` (`Date` ASC, `Time` ASC) INVISIBLE)" % table

                #print(sql)

                try:
                    # 执行sql语句
                    cursor.execute(sql)
                    # 提交到数据库执行
                    db.commit()
                except:
                    # 发生错误时回滚
                    db.rollback()

                """
                sql = "ALTER TABLE `%s` ADD INDEX `Date_Time_Index` (`Date` ASC, `Time` ASC) VISIBLE" % table

                try:
                    # 执行sql语句
                    cursor.execute(sql)
                    # 提交到数据库执行
                    db.commit()
                except:
                    # 发生错误时回滚
                    db.rollback()
                """

                last = ""
                number = 0
                for data in historyData:
                    last = data
                    number += 1
                    # print("历史行情：Date:%s, Time:%s, Open:%s,High:%s, Low:%s, Close:%s,Volume:%s, UpTick:%s, UpVolume:%s,DownTick:%s, DownVolume:%s, UnchVolume:%s, QryIndex:%s" % (data["Date"],data["Time"], data["Open"], data["High"], data["Low"], data["Close"], data["Volume"], data["UpTick"], data["UpVolume"], data["DownTick"], data["DownVolume"], data["UnchVolume"], data["QryIndex"]))
                    # SQL 插入语句minute(

                    if data["Time"] != "0":

                        sql = "INSERT INTO %s (\
                               Date, Time, Open, High, Low, Close, Volume, UpTick, UpVolume, DownTick, DownVolume, UnchVolume, QryIndex, Timestamp) \
                               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, unix_timestamp(%s))" % \
                              (table, data["Date"], data["Time"], data["Open"], data["High"], data["Low"], data["Close"],
                               data["Volume"], data["UpTick"], data["UpVolume"], data["DownTick"], data["DownVolume"],
                               data["UnchVolume"], data["QryIndex"], data["Date"] + "0" + data["Time"])

                    else:
                        sql = "INSERT INTO %s (\
                                                       Date, Time, Open, High, Low, Close, Volume, UpTick, UpVolume, DownTick, DownVolume, UnchVolume, QryIndex, Timestamp) \
                                                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, unix_timestamp(%s))" % \
                        (table, data["Date"], data["Time"], data["Open"], data["High"], data["Low"], data["Close"],
                              data["Volume"], data["UpTick"], data["UpVolume"], data["DownTick"], data["DownVolume"],
                              data["UnchVolume"], data["QryIndex"], data["Date"])

                    #print(sql)

                    try:
                        # 执行sql语句
                        cursor.execute(sql)
                        # 提交到数据库执行
                        db.commit()
                    except:
                        # 发生错误时回滚
                        db.rollback()

                strQryIndex = last["QryIndex"]
                print(number)

    return


def main():
    global g_QuoteZMQ
    global g_QuoteSession

    # 登入
    g_QuoteZMQ = tcore_zmq("ZMQ", "8076c9867a372d2a9a814ae710c256e2")

    q_data = g_QuoteZMQ.quote_connect("51734")
    print(q_data)

    if q_data["Success"] != "OK":
        print("[quote]connection failed")
        return

    g_QuoteSession = q_data["SessionKey"]
    g_QuoteZMQKeepAlive = KeepAliveHelper(q_data["SubPort"], g_QuoteSession, g_QuoteZMQ)

    # 登出
    # q_logout= g_QuoteZMQ.quote_logout(q_data["SessionKey"])
    # print(q_logout)

    # g_QuoteZMQKeepAlive.Close()

    # 查询指定合约信息
    # print("查询指定合约：", g_QuoteZMQ.QueryInstrumentInfo(g_QuoteSession, "TC.O.SSE.510050.202110.C.2.95"))
    # 查询指定类型合约列表
    # 期货：Future
    # 期权：Options
    # 证券：Stock
    # print("查询证券合约：", g_QuoteZMQ.QueryAllInstrumentInfo(g_QuoteSession, "Stock"))
    '''
    optionsdata = g_QuoteZMQ.QueryAllInstrumentInfo(g_QuoteSession, "Options")
    print("查询期权合约Reply：", optionsdata["Reply"])
    print("查询期权合约Success：", optionsdata["Success"])
    optionsdataInfo = optionsdata["Instruments"]
    #optionsdataInfo = json.loads(optionsdata["Instruments"])
    for data in optionsdataInfo:

        #json解析有问题
        print("查询期权合约ENG：%s" % optionsdata["Instruments"]["ENG"])

        print("查询期权合约ENG：", data["CHT"])
        print("查询期权合约ENG：", data["CHS"])
        print("查询期权合约ENG：", data["EXGID"])
        dataNode = data["Node"]
        for dataNodeOne in dataNode:
            print("查询期权合约ENG：", dataNodeOne)
'''

    #####################################################################行情################################################
    # 建立一个行情线程
    t2 = threading.Thread(target=quote_sub_th, args=(g_QuoteZMQ, q_data["SubPort"],))
    t = t2
    t2.start()
    # 实时行情订阅
    # 解除订阅
    # g_QuoteZMQ.unsubquote(g_QuoteSession, "TC.O.SSE.510050.202110.C.2.95")
    # 订阅实时行情
    # g_QuoteZMQ.subquote(g_QuoteSession, "TC.O.SSE.510050.202110.C.2.95")

    # 实时Greeks订阅
    # 解除订阅
    # g_QuoteZMQ.unsubgreeks(g_QuoteSession, "TC.O.SSE.510050.202110.C.2.95")
    # 订阅实时行情
    # g_QuoteZMQ.subgreeks(g_QuoteSession, "TC.O.SSE.510050.202110.C.2.95")

    # 历史数据订阅
    History_obj = {
        # "Symbol": "TC.O.SSE.510050.202110.C.2.9",
        # "Symbol": "TC.S.SSE.510050",
        "Symbol": "TC.O.SSE.510050.202112.P.3.7",
        "SubDataType": "1K",
        "StartTime": "2021082223",
        "EndTime":   "2022012616"
    }

    # 订阅历史数据
    # g_QuoteZMQ.sub_history(g_QuoteSession, History_obj)

    l = [2.8, 2.85, 2.9, 2.95, 3, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 4, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9]
    o = ['C', 'P']
    t = ["DK", "1K"]

    for i in o:
        for j in l:
            for k in t:
                History_obj["Symbol"] = "TC.O.SSE.510050.202201." + i + "." + str(j)
                History_obj["SubDataType"] = k
                g_QuoteZMQ.sub_history(g_QuoteSession, History_obj)


if __name__ == '__main__':
    main()

# t.stop()

# 关闭数据库连接
# db.close()